GSug Keyword Scraper
====================
Author: Epigrade
Author website: https://www.epigrade.com/

Description of Options
======================
- Engine - currently only google.com is available, meaning it will scrape keywords from Google autocomplete.
- Lang - language in which to scrape keywords from the search engine. Currently only English is supported.
- Root Keyword - Here you should enter the root keyword to find longtails for. For example "dog" or "dog food".
- Char List - list of characters that get appended to the root keyword to find longtail keywords.
- Depth - autocomplete depth. For example if root keyword is "dog" and Depth is set to 1 it will search suggestions starting with "dog a" all the way to "dog 9". If Depth is set to 2, it will search suggestions starting with "dog a" all the way to "dog 99".
- Recursive Scraping - Enable recursive scraping. This allows for each keyword scraped to append characters from the Char List again to it and scrape suggestions for that longtail keyword too.
- Enable on Depth - range of depths from main scraping loop (defined by Depth field) on which to apply the recursive scraping.
- Enable on wordcount - range of wordcounts for keywords scraped from main loop on which to enable recursive scraping. If Enable on wordcount is set to 1-2 it will do recursive scraping only on keywords made up of a single word or two words and keywords longer or equal to 3 words will not go through recursive scraping.
- Scraping depth - this is the recursive scraping depth. For most uses 2 catches most longtail keywords.
- Use proxies - enable or disable proxy use. You can click the "B" (which stands for "Browse") button to select the proxies file to use. Within the file proxies must be entered one per line in the format "ip:port:username:password".
- Max fails - maximum number of failures using one proxy until it stops using it.
- On no proxy - action to take when there are no more usable proxies.
- Threads - the software has multi-threading support and using this field you can instruct it how many threads to use when it is scraping.
- Delay - delay in milliseconds between two requests.
- Timeout - timeout before a request stops and is considered a failure. Recommend to set this to 15000 (15 seconds) or higher.
- Start button - start scraping.
- Pause button - pause scraping but maintain program state.
- Reload proxies - reloads proxies from the file. If you made changes to the proxies (for example you entered fresh proxies) file it reloads it.
- Clear - clears the keywords list and keywords.txt file.
- Deduplicate - removes duplicate keywords from the list and keywords.txt file.
- Export - exports the keywords list to a specified file.


Notes
=====
Keep in mind that for backup purposes in case of a crash, the software maintains a backup in keywords.txt file as it is running it's normal operation. That means it is disk intensive and if you use it a lot on SSD or NVMe storage it may reduce the lifetime of such storage device.

